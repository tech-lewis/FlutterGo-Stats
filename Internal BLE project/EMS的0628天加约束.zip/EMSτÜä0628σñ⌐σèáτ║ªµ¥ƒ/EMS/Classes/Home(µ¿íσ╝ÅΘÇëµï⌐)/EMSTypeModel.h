//
//  EMSTypeModel.h
//  EMS
//
//  Created by 柏霖尹 on 2019/6/26.
//  Copyright © 2019 work. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface EMSTypeModel : NSObject
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *subtitle;
@end

NS_ASSUME_NONNULL_END
