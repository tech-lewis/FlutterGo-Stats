//
//  EMSViedoListCell.h
//  EMS
//
//  Created by 柏霖尹 on 2019/6/29.
//  Copyright © 2019 work. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EMSVideoModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface EMSViedoListCell : UITableViewCell
@property (nonatomic, strong) EMSVideoModel *model;
/**
 // 显示运动项目的名称
 */
@property (nonatomic, copy) NSString *title;
+ (instancetype)cellWithTableView:(UITableView *)tableview;


@end

NS_ASSUME_NONNULL_END
