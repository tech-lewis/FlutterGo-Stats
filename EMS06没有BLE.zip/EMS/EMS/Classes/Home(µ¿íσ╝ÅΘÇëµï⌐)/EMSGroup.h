//
//  EMSGroup.h
//  EMS
//
//  Created by 柏霖尹 on 2019/6/24.
//  Copyright © 2019 work. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface EMSGroup : NSObject
// 菜单的标题文字
@property (nonatomic, copy) NSString *name;

// 选中时的韩文
@property (nonatomic, copy) NSString *nameSelected;
/**
 *  数组中装的都是Menu菜单模型
 */
@property (nonatomic, strong) NSArray *menus;

/**
 *  标识这组是否需要展开,  YES : 展开 ,  NO : 关闭
 */
@property (nonatomic, assign, getter = isOpened) BOOL opened;

+ (instancetype)groupWithDict:(NSDictionary *)dict;
- (instancetype)initWithDict:(NSDictionary *)dict;
@end

NS_ASSUME_NONNULL_END

