//
//  EMSMenuModel.m
//  EMS
//
//  Created by 柏霖尹 on 2019/6/24.
//  Copyright © 2019 work. All rights reserved.
//

#import "EMSMenuModel.h"

@implementation EMSMenuModel

+ (instancetype)menuWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}

- (instancetype)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}
@end
