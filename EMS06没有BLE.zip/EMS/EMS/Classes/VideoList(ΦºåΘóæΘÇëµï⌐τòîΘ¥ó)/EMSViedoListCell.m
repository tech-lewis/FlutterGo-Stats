//
//  EMSViedoListCell.m
//  EMS
//
//  Created by 柏霖尹 on 2019/6/29.
//  Copyright © 2019 work. All rights reserved.
//

#import "EMSViedoListCell.h"
@interface EMSViedoListCell()
@property (nonatomic, weak) UIButton *titleButton;
@property (nonatomic, weak) UIImageView *iconImageView;

@end


@implementation EMSViedoListCell
+ (instancetype)cellWithTableView:(UITableView *)tableview
{
    static NSString *ID = @"videoCell";
    EMSViedoListCell *cell = [tableview dequeueReusableCellWithIdentifier:ID];
    if (cell == nil)
    {
        cell = [[EMSViedoListCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:ID];
        cell.backgroundColor = [UIColor clearColor];
    }
    return cell;
    
}


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        // 初始化子控件
        
        // 添加一个不能点击的按钮到Cell上
        UIButton *button = [[UIButton alloc] init];
        [button setImage:[UIImage imageNamed:@"ems_checkbox_n"] forState:UIControlStateNormal];
        [button setImage:[UIImage imageNamed:@"ems_checkbox_p"] forState:UIControlStateSelected];
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [button setTitleColor:LLColor(65, 200, 253) forState:UIControlStateSelected];
        button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        [button.titleLabel setFont:[UIFont fontWithName:@"BodyFriendM" size:15]];
        button.userInteractionEnabled = NO;
        [button setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 50)];
        [button setTitleEdgeInsets:UIEdgeInsetsMake(0, 50, 0, 0)];
        self.titleButton = button;
        
        
        
        // 添加一个小图标到按钮的上面
        UIImageView *imageview = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 32, 32)];
        self.iconImageView = imageview;
        [self addSubview:imageview];
        [self addSubview:button];
    }
    return self;
}

#pragma mark - 修改模型属性设置字体状态
- (void)setModel:(EMSVideoModel *)model
{
    _model = model;
    // 设置按钮的标题文字
#warning title对应的韩语字典
    // 设置按钮的标题  注意选中状态为韩语
    [self.titleButton setTitle:model.name forState:UIControlStateNormal];
    [self.titleButton setTitle:model.selectName forState:UIControlStateSelected];
    // 修改按钮的背景
    self.titleButton.selected = model.isSelect;
    
    // 设置图标
    self.iconImageView.image = [UIImage imageWithEmsName:model.icon];
    self.iconImageView.highlightedImage = [UIImage selectImageWithEmsName:model.icon];
    self.iconImageView.highlighted = model.isSelect;
}


- (void)layoutSubviews
{
    [super layoutSubviews];
    // 按钮的尺寸大小
    CGRect rect = self.bounds;
    //NSLog(@"%@", NSStringFromCGRect(rect));
    self.titleButton.frame = rect;
    
    _iconImageView.center = self.titleButton.center;
    _iconImageView.x = CGRectGetMaxX(self.titleButton.imageView.frame)+5;
    // add Line
    UIImageView *line = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.bounds.size.width, 2)];
    line.y = self.bounds.size.height-2;
    line.image = [UIImage resizedImageWithName:@"ems_list_line"];
    [self addSubview:line];
}

//
- (void)awakeFromNib
{
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
