//
//  UIImage+Extension.h
//  EMS
//
//  Created by 柏霖尹 on 2019/6/25.
//  Copyright © 2019 work. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (Extension)
+ (UIImage *)resizedImageWithName:(NSString *)name;
+ (UIImage *)resizedImageWithName:(NSString *)name left:(CGFloat)left top:(CGFloat)top;

// 返回对应图标的Image
+ (UIImage *)imageWithEmsName:(NSString *)name;
+ (UIImage *)selectImageWithEmsName:(NSString *)name;


@end

NS_ASSUME_NONNULL_END
