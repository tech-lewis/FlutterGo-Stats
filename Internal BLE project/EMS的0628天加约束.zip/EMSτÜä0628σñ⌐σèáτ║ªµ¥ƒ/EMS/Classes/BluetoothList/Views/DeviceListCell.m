//
//  DeviceListCell.m
//  EMS
//
//  Created by 柏霖尹 on 2019/6/22.
//  Copyright © 2019 work. All rights reserved.
//

#import "DeviceListCell.h"
@interface DeviceListCell()

@property (nonatomic, weak) UIButton *titleButton;
@end

@implementation DeviceListCell

+ (instancetype)cellWithTableView:(UITableView *)tableView
{
    static NSString *ID = @"deviceListCell";
    DeviceListCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil)
    {
        cell = [[DeviceListCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:ID];
        
        cell.backgroundColor = [UIColor clearColor];
    }
    return cell;
}


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) { // 初始化子控件
        
        // 添加一个不能点击的按钮到Cell上
        UIButton *button = [[UIButton alloc] init];
        [button setImage:[UIImage imageNamed:@"ems_checkbox_n"] forState:UIControlStateNormal];
        [button setImage:[UIImage imageNamed:@"ems_checkbox_p"] forState:UIControlStateSelected];
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [button setTitleColor:LLColor(65, 200, 253) forState:UIControlStateSelected];
        [button setTitleEdgeInsets:UIEdgeInsetsMake(0, 10, 0, 10)];
        button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    
        
        button.userInteractionEnabled = NO;
        [self addSubview:button];
        [self.titleButton addTarget:self action:@selector(pressedButton:) forControlEvents:UIControlEventTouchUpInside];
        self.titleButton = button;
    }
    return self;
}


- (void)pressedButton:(UIButton *)sender
{
    sender.selected = !sender.selected;
    
    
}
#pragma mark - 修改模型属性设置字体状态
- (void)setChecked:(BOOL)checked
{
    _checked = checked;
    // 设置字体颜色和按钮选择状态
    self.titleButton.selected = checked;
}

- (void)setTitle:(NSString *)title
{
    _title = title;
    // 设置按钮的标题
    [self.titleButton setTitle:title forState:UIControlStateNormal];
    [self.titleButton setTitle:title forState:UIControlStateSelected];
    [self.titleButton setTitle:title forState:UIControlStateHighlighted];
}


- (void)layoutSubviews
{
    [super layoutSubviews];
    
    // 按钮的尺寸大小
    CGSize size =self.frame.size;
    self.titleButton.frame = CGRectMake(0, 0, size.width, size.height);
}

- (void)setFrame:(CGRect)frame
{
    // 调用x系统设置frame的方法 设置frame
    
    //
    [super setFrame:frame];
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
