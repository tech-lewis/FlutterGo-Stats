//
//  EMSTypeModel.m
//  EMS
//
//  Created by 柏霖尹 on 2019/6/26.
//  Copyright © 2019 work. All rights reserved.
//

#import "EMSTypeModel.h"

@implementation EMSTypeModel

@end
