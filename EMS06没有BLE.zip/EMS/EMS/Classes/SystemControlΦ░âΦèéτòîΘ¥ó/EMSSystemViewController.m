//
//  EMSSystemViewController.m
//  EMS
//
//  Created by 柏霖尹 on 2019/6/26.
//  Copyright © 2019 work. All rights reserved.
//

#import "EMSSystemViewController.h"
#import "SystemControlMaleView.h"
#import "SystemControlFemaleView.h"
#import "EMSVideoChooseViewController.h"
#import "EMSVideoModel.h"
@interface EMSSystemViewController ()
{
    SystemControlMaleView *clotheView;
}
@property (weak, nonatomic) IBOutlet UILabel *relaxLabel;
@property (weak, nonatomic) IBOutlet UILabel *workLabel; //
@property (weak, nonatomic) IBOutlet UIView *clotheContentView;
@property (weak, nonatomic) IBOutlet UIView *HMLView;
@property (weak, nonatomic) IBOutlet UIView *emsTimeView;
@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *hmlButtons;
// 存放着模型的数组
@property (nonatomic, strong) NSArray<EMSVideoModel *> *models;
- (IBAction)adjustmentButtonClick:(UIButton *)sender;// 高中低调节按钮的点击事件
- (IBAction)workTimePlusAction:(id)sender;// 调节时间的点击事件workTimePlusAction
- (IBAction)workTimeMinusAction;
- (IBAction)relaxTimeMinusAction;
- (IBAction)relaxTimePlusAction;
@end

@implementation EMSSystemViewController
- (IBAction)openVideoSelection:(id)sender
{
    EMSVideoChooseViewController *vc = [[EMSVideoChooseViewController alloc] init];
    vc.models = self.models;
    [self.navigationController pushViewController:vc animated:YES];
}

- (IBAction)plusButtonClicked
{
    [clotheView plusButtonAction];
}
- (IBAction)minusButtonClicked
{
    [clotheView minusButtonAction];
}


- (void)setModelDictArray:(NSArray *)modelDictArray
{
    _modelDictArray = modelDictArray;
    
    // 获得模型数组并传递给下一个控制器
    NSMutableArray *array = [NSMutableArray array];
    for (id dict in self.modelDictArray)
    {
        EMSVideoModel *model = [EMSVideoModel videoListWithDict:dict];
        [array addObject:model];
    }
    self.models = array;
    
}
#pragma mark - Lifecycle
- (void)injection{LLog(@"debug");}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setupChileViews];
}

- (void)setupChileViews
{
    UIImageView *line = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 107, 1)];
    line.image = [UIImage resizedImageWithName:@"ems_list_line"];
    line.y = CGRectGetMaxY(self.HMLView.bounds)-1;
    [self.HMLView addSubview:line];
    
     clotheView=nil;
    if(self.isMaleGender)
    {
        clotheView = [SystemControlMaleView systemControlMaleView];
    }
    else
    {
        //female clothe
        //clotheView = [clotheView systemControlMaleView];
#warning
    }
    // 设置运动衣的视图
    clotheView.frame=CGRectMake(0, 0, self.clotheContentView.frame.size.width,self.clotheContentView.height);
    [self.clotheContentView addSubview:clotheView];
    //[clotheView performSelector:@selector(selectAllButtons)];
    
    
    CGFloat x = CGRectGetMinX(_workLabel.frame);
    CGFloat y = CGRectGetMaxY(_workLabel.frame)+1;
    UIView *whiteLine1 = UIView.new;
    whiteLine1.frame = CGRectMake(x, y, _workLabel.width, 2);
    whiteLine1.backgroundColor = UIColor.whiteColor;
    [_emsTimeView addSubview:whiteLine1];
    
    x = CGRectGetMinX(_relaxLabel.frame);
    y = CGRectGetMaxY(_relaxLabel.frame)+1;
    UIView *whiteLine2 = UIView.new;
    whiteLine2.frame = CGRectMake(x, y, _relaxLabel.width, 2);
    whiteLine2.backgroundColor = UIColor.whiteColor;
    [_emsTimeView addSubview:whiteLine2];
    
}

-(void)viewDidLayoutSubviews{
    [super viewDidLayoutSubviews];
    clotheView.frame=CGRectMake(0, 0, self.clotheContentView.frame.size.width,self.clotheContentView.height);
}

- (IBAction)selectAllButtonClicked:(UIButton *)sender
{
    sender.selected = !sender.isSelected;
    
    if(sender.isSelected)
    {
        [clotheView selectAllButtons];
    }
    else
    {
        [clotheView deselectAllButtons];
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)adjustmentButtonClick:(UIButton *)sender
{
    // 记录选中的按钮 得到标题
    for (UIButton *btn in _hmlButtons)
    {
        btn.selected = NO;
    }
    
    // 设置选中的按钮
    sender.selected = YES;
    int tag = (int)sender.tag;
    
    switch (tag) {
        case 1:
            //高档按钮 调整预设
            [clotheView setAllButtonTitleForHighValue];
            break;
        case 2:
            //中档按钮 调整预设
            [clotheView setAllButtonTitleForMiddleValue];
            break;
        case 3:
            //低档按钮 调整预设
            [clotheView setAllButtonTitleForLowValue];
            break;
        default:
            break;
    }
#warning 修改文字标题
    
}



#pragma mark - 调节 工作与休息时间的点击事件
- (IBAction)workTimePlusAction:(id)sender
{
    // 工作时间 +1s
    int value = [[self.workLabel.text substringWithRange:NSMakeRange(0, 1)] intValue];
#warning 添加具体的t业务实现代码
    if(value>=9) value=-1;
    _workLabel.text = [NSString stringWithFormat:@"%d초", ++value];

}

- (IBAction)workTimeMinusAction
{

    // 工作时间 +1s

    // 工作时间 -1s
    int value = [[self.workLabel.text substringWithRange:NSMakeRange(0, 1)] intValue];
#warning 添加具体的t业务实现代码
    
    value--;
    if(value<0) value=0;
    _workLabel.text = [NSString stringWithFormat:@"%d초", value];

}

- (IBAction)relaxTimeMinusAction
{
    // 工作时间 -1s
    int value = [[self.relaxLabel.text substringWithRange:NSMakeRange(0, 1)] intValue];
#warning 添加具体的t业务实现代码
    
    value--;
    if(value<0) value=0;
    _relaxLabel.text = [NSString stringWithFormat:@"%d초", value];

}

- (IBAction)relaxTimePlusAction
{
    int value = [[self.relaxLabel.text substringWithRange:NSMakeRange(0, 1)] intValue];
#warning 添加具体的t业务实现代码
    if(value>=9) value=-1;
    _relaxLabel.text = [NSString stringWithFormat:@"%d초", ++value];
}
@end
