//
//  EMSGroup.m
//  EMS
//
//  Created by 柏霖尹 on 2019/6/24.
//  Copyright © 2019 work. All rights reserved.
//

#import "EMSGroup.h"
#import "EMSMenuModel.h"
@implementation EMSGroup

+ (instancetype)groupWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}

- (instancetype)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        // 1.注入所有属性
        [self setValuesForKeysWithDictionary:dict];
        
        // 2.特殊处理menus属性
        NSMutableArray *menusArray = [NSMutableArray array];
        for (NSDictionary *dict in self.menus) {
            EMSMenuModel *menu = [EMSMenuModel menuWithDict:dict];
            [menusArray addObject:menu];
        }
        self.menus = menusArray;
    }
    return self;
}


@end
