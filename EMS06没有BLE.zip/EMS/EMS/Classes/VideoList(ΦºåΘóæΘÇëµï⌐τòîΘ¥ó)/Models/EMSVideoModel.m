//
//  EMSVideoModel.m
//  EMS
//
//  Created by 柏霖尹 on 2019/7/1.
//  Copyright © 2019 work. All rights reserved.
//

#import "EMSVideoModel.h"

@implementation EMSVideoModel
+ (instancetype)videoListWithDict:(NSDictionary *)dict;
{
    return [[self alloc] initWithDict:dict];
}

- (instancetype)initWithDict:(NSDictionary *)dict
{
    if (self = [super init])
    {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    // 没有的键
}
@end
