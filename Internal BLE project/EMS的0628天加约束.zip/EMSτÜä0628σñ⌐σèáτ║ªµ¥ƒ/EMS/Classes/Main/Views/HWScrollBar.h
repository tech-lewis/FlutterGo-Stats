//
//  HWScrollBar.h
//  HWScrollBar
//
//  Created by sxmaps_w on 2017/6/22.
//  Copyright © 2017年 wqb. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HWScrollBar;

@protocol HWScrollBarDelegate <NSObject>

//滚动条滑动代理事件
- (void)scrollBarDidScroll:(HWScrollBar *)scrollBar;

//滚动条点击代理事件
- (void)scrollBarTouchAction:(HWScrollBar *)scrollBar;

@end

@interface HWScrollBar : UIView

//背景色
@property (nonatomic, strong) UIColor *backColor;

//前景色
@property (nonatomic, strong) UIColor *foreColor;

//滚动动画时长
@property (nonatomic, assign) CGFloat barMoveDuration;

//限制滚动条最小高度
@property (nonatomic, assign) CGFloat minBarHeight;

//滚动条实际高度
@property (nonatomic, assign) CGFloat barHeight;

//滚动条Y向位置
@property (nonatomic, assign) CGFloat yPosition;

//代理
@property (nonatomic, weak) id<HWScrollBarDelegate> delegate;

@end
