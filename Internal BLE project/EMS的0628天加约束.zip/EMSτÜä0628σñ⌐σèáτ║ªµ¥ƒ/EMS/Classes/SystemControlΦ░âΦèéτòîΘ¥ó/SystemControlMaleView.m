//
//  SystemControlMaleView.m
//  EMS
//
//  Created by 柏霖尹 on 2019/6/27.
//  Copyright © 2019 work. All rights reserved.
//

#import "SystemControlMaleView.h"
#import "UIImageView+Extension.h"
@interface SystemControlMaleView()

/** 左右胸的背景图*/
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *blueView1;
/** 左右手袖的背景图*/
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *blueView2;
/** 左右腹部的背景图*/
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *blueView3;
/** 左右大腿的背景图*/
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *blueView4;

/** rear左右颈部的背景图*/
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *rearBlueView1;
/** rear左右胸的背景图*/
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *rearBlueView2;
/** rear左右腹部的背景图*/
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *rearBlueView3;
/** rear左右腹部的背景图*/
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *rearBlueView4;
/** rear左右大腿的背景图*/
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *rearBlueView5;
/** rear左右腹部的背景图*/
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *rearBlueView6;





@end


@implementation SystemControlMaleView

+(instancetype)systemControlMaleView
{
    NSBundle *bundle = [NSBundle mainBundle];
    // 读取xib文件(会创建xib中的描述的所有对象)
    NSArray *objs = [bundle loadNibNamed:@"SystemControlMaleView" owner:self options:nil];
    SystemControlMaleView *maleView = [objs lastObject];
    return maleView;
}





#pragma mark - 按钮的处理方法
- (void)deselectAllButtons
{
    // 让所有的图片都变成高亮
    [self.blueView1 makeObjectsPerformSelector:@selector(deselectImageView)];
    [self.blueView2 makeObjectsPerformSelector:@selector(deselectImageView)];
    [self.blueView3 makeObjectsPerformSelector:@selector(deselectImageView)];
    [self.blueView4 makeObjectsPerformSelector:@selector(deselectImageView)];
    
    
    [self.rearBlueView1 makeObjectsPerformSelector:@selector(deselectImageView)];
    [self.rearBlueView2 makeObjectsPerformSelector:@selector(deselectImageView)];
    [self.rearBlueView3 makeObjectsPerformSelector:@selector(deselectImageView)];
    [self.rearBlueView4 makeObjectsPerformSelector:@selector(deselectImageView)];
    [self.rearBlueView5 makeObjectsPerformSelector:@selector(deselectImageView)];
    [self.rearBlueView6 makeObjectsPerformSelector:@selector(deselectImageView)];
    
}


- (void)selectAllButtons
{
    // 让所有的图片都变成高亮
    [self.blueView1 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
    [self.blueView2 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
    [self.blueView3 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
    [self.blueView4 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
    
    [self.rearBlueView1 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
    [self.rearBlueView2 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
    [self.rearBlueView3 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
    [self.rearBlueView4 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
    [self.rearBlueView5 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
    [self.rearBlueView6 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
}


#pragma mark - 监听按钮的点击事件

- (IBAction)frontButtonAction:(UIButton *)sender
{
    // 左右胸按钮点击处理
    sender.selected = !sender.isSelected;
    
    NSInteger mytag = sender.tag/10;
    if(sender.isSelected)
    {
        // 背景色设置为红色
        switch (mytag) {
            case 1:
                
                [self.blueView1 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
                break;
            case 2:
                [self.blueView2 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
                break;
            case 3:
                [self.blueView3 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
                break;
            case 4:
                [self.blueView4 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
                break;
            default:
                break;
        }
    }
    else
    {
        // 背景色设置为蓝色
        switch (mytag) {
            case 1:
                [self.blueView1 makeObjectsPerformSelector:@selector(deselectImageView)];
                break;
            case 2:
                [self.blueView2 makeObjectsPerformSelector:@selector(deselectImageView)];
                break;
            case 3:
                [self.blueView3 makeObjectsPerformSelector:@selector(deselectImageView)];
                break;
            case 4:
                [self.blueView4 makeObjectsPerformSelector:@selector(deselectImageView)];
                break;
            default:
                break;
        }
    }
    
}

- (IBAction)rearButtonAction:(UIButton *)sender
{
    // 左右胸按钮点击处理
    sender.selected = !sender.isSelected;
    // 为了区分衣服前后贴片的按钮样式
    NSInteger mytag = sender.tag/100;
    if(sender.isSelected)
    {
        // 背景色设置为红色
        switch (mytag) {
            case 1:
                [self.rearBlueView1 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
                break;
            case 2:
                [self.rearBlueView2 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
                break;
            case 3:
                [self.rearBlueView3 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
                break;
            case 4:
                [self.rearBlueView4 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
                break;
            case 5:
                [self.rearBlueView5 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
                break;
            case 6:
                [self.rearBlueView6 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
                break;
            default:
                break;
        }
    }
    else
    {
        // 背景色设置为蓝色
        switch (mytag) {
            case 1:
                [self.rearBlueView1 makeObjectsPerformSelector:@selector(deselectImageView)];
                break;
            case 2:
                [self.rearBlueView2 makeObjectsPerformSelector:@selector(deselectImageView)];
                break;
            case 3:
                [self.rearBlueView3 makeObjectsPerformSelector:@selector(deselectImageView)];
                break;
            case 4:
                [self.rearBlueView4 makeObjectsPerformSelector:@selector(deselectImageView)];
                break;
            case 5:
                [self.rearBlueView5 makeObjectsPerformSelector:@selector(deselectImageView)];
                break;
            case 6:
                [self.rearBlueView6 makeObjectsPerformSelector:@selector(deselectImageView)];
                break;
            default:
                break;
        }
    }
    
}


-(void)layoutSubviews{
    [super layoutSubviews];
    
    
    \
    
    
}



@end
