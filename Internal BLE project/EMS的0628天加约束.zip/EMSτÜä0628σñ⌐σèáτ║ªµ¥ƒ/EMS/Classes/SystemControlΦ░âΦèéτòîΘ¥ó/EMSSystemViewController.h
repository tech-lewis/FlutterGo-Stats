//
//  EMSSystemViewController.h
//  EMS
//
//  Created by 柏霖尹 on 2019/6/26.
//  Copyright © 2019 work. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface EMSSystemViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *listLineView;
@property (nonatomic, assign) BOOL isMaleGender; //is男性 否则是女性
@end

NS_ASSUME_NONNULL_END
