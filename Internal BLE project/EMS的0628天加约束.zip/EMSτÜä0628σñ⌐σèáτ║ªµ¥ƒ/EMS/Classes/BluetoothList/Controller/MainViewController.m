//
//  MainViewController.m
//  EMS
//
//  Created by 柏霖尹 on 2019/6/22.
//  Copyright © 2019 work. All rights reserved.
//  蓝牙设备的选择界面控制器

#import "MainViewController.h"
#import "DeviceListCell.h"
#import "EMSContradicationViewController.h"
@interface MainViewController ()<UITableViewDelegate, UITableViewDataSource>
// 蓝牙设备选择界面
@property (weak, nonatomic) UITableView *tableView;
@property (strong, nonatomic) NSArray *array;
@property (weak, nonatomic) IBOutlet UIImageView *circleImageView;
- (IBAction)selectDeviceButtonClick:(id)sender;


@end

@implementation MainViewController

- (NSArray *)array
{
    if(_array == nil)
    {
        NSString *path = [[NSBundle mainBundle] pathForResource:@"deviceList.plist" ofType:nil];
        
        _array = [NSArray arrayWithContentsOfFile:path];
    }
    
    return _array;
}



- (void)setupTableView
{
    // 蓝牙设备的列表
    CGFloat x = self.view.bounds.size.width*0.5;
    CGFloat y = 50;
    CGFloat width = x-20;
    CGFloat height = 100;
    UITableView *tableview = [[UITableView alloc] initWithFrame:CGRectMake(x, y, width, height) style:UITableViewStylePlain];
    tableview.delegate = self;
    tableview.dataSource = self;
    [self.view addSubview:tableview];
    self.tableView = tableview;
    self.tableView.backgroundColor = [UIColor clearColor];
}


// 头部的提示性文字
- (void)setupTopView
{
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"content";
    NSLog(@"%@", [SystemTool iphoneType]);
    // setupControls
    //[self startCircleViewAnimation];
    [self setupTopView];
    [self setupTableView];
    // 获得蓝牙设备列表
#warning bluetooth
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    // 开始动画
    [self startCircleViewAnimation];
}
- (void)startCircleViewAnimation
{
    CABasicAnimation *animation =  [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    
    //默认是顺时针效果，若将fromValue和toValue的值互换，则为逆时针效果
    animation.fromValue = [NSNumber numberWithFloat:0.f];
    animation.toValue =  [NSNumber numberWithFloat: M_PI *2];
    animation.duration  = 1;
    animation.autoreverses = NO;
    animation.fillMode =kCAFillModeForwards;
    animation.repeatCount = MAXFLOAT; //如果这里想设置成一直自旋转，可以设置为MAXFLOAT，否则设置具体的数值则代表执行多少次
    [self.circleImageView.layer addAnimation:animation forKey:nil];

}

#pragma mark - TableView 代理和数据源方法
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    DeviceListCell *cell = [DeviceListCell cellWithTableView:tableView];
    // setup cell...
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    #warning 设置设备的名称
    cell.title = @"蓝牙测试设备";
    return cell;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    DeviceListCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    cell.checked = !cell.isChecked;
}


#pragma mark - 蓝牙连接成功后

- (IBAction)selectDeviceButtonClick:(id)sender
{
    // 进入操作界面 前显示使用提示界面
    EMSContradicationViewController *contradicationVC = [[EMSContradicationViewController alloc] init];
    self.navigationController.navigationBar.translucent = YES;
    [self.navigationController pushViewController:contradicationVC animated:YES];
    
}

@end
