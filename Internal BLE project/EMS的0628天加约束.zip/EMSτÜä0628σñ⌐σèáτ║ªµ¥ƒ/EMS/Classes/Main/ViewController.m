//
//  ViewController.m
//  EMS
//
//  Created by 柏霖尹 on 2019/6/22.
//  Copyright © 2019 work. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
	
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor grayColor];
}


@end
