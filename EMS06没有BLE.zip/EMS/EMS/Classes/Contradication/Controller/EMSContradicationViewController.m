//
//  EMSContradicationViewController.m
//  EMS
//
//  Created by 柏霖尹 on 2019/6/22.
//  Copyright © 2019 work. All rights reserved.
//

#import "EMSContradicationViewController.h"
#import "HWScrollBar.h"
#import "MainViewController.h"
#import "EMSNavigationViewController.h"
@interface EMSContradicationViewController ()<UIScrollViewDelegate, HWScrollBarDelegate, UITextViewDelegate>
@property (weak, nonatomic) IBOutlet UIButton *nextButton;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (nonatomic, strong) UIView *checkedView;
@property (nonatomic, strong) UILabel *textLabel;
//  自定义滚动条
#warning scrollBar
@property (strong, nonatomic) HWScrollBar *scrollbar;
- (IBAction)openMainViewController:(UIButton *)sender;

@property (weak, nonatomic) IBOutlet UIImageView *checkImageView;
@property (weak, nonatomic) IBOutlet UIView *checkboxContentView;
// 同意复选框点击的方法
- (IBAction)checkboxClicked:(id)sender;



@end

@implementation EMSContradicationViewController
#pragma mark - Lifecycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"Contraindication-韩文";
    
    [self setupScrollLabel];
    
    self.navigationController.navigationBar.translucent = YES;
}

- (void)setupScrollLabel
{
    // 设置scrollView的属性
    self.scrollView.indicatorStyle = UIScrollViewIndicatorStyleWhite;
    self.scrollView.delegate = self;

    // 设置文本框的尺寸
    UILabel *label = [[UILabel alloc] init];
    label.numberOfLines = 0;
    [self.scrollView addSubview:label];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.scrollView);
        make.width.equalTo(self.scrollView);
    }];
    self.textLabel = label;
    [self setupAttributeTextForLabel];
    [self subviewLayout];
    
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self setupScrollBar];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    [self.scrollbar removeFromSuperview];
    self.scrollbar = nil;
}



- (void)setupScrollBar
{
    self.scrollView.showsVerticalScrollIndicator = NO;
    // 确定 autolayout的控件frame
    //    LLog(@"%@", NSStringFromCGRect(self.textView.frame));
    //滚动展示条
    HWScrollBar *bar = [[HWScrollBar alloc] initWithFrame:CGRectMake(CGRectGetMaxX(_scrollView.frame), CGRectGetMinY(_scrollView.frame)+5, 2, _scrollView.bounds.size.height)];
    bar.foreColor = [UIColor whiteColor];
    bar.userInteractionEnabled = NO;
    [self.view addSubview:bar];
    self.scrollbar = bar;
}

#pragma mark - ScrollView 代理方法
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    //更新滚动条位置
    self.scrollbar.yPosition = (self.scrollbar.bounds.size.height - self.scrollbar.barHeight) * scrollView.contentOffset.y / (scrollView.contentSize.height - self.scrollbar.bounds.size.height);
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    // 开始滚动textview
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        //更新滚动条高度
        if (self.scrollView.contentSize.height <= self.scrollView.bounds.size.height)
        {
            self.scrollbar.barHeight = self.scrollView.bounds.size.height;
        }
        else
        {
            self.scrollbar.barHeight = pow(self.scrollView.bounds.size.height, 2) / self.scrollView.contentSize.height;
        }
        
        
        //更新滚动条Y向位置
        self.scrollbar.yPosition = (self.scrollbar.bounds.size.height - self.scrollbar.barHeight) * self.scrollView.contentOffset.y / (self.scrollView.contentSize.height - self.scrollbar.bounds.size.height);
    });
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - Layout subviews

#pragma mark - SXScrollBarDelegate
- (void)scrollBarDidScroll:(HWScrollBar *)scrollBar
{
    [self.scrollView setContentOffset:CGPointMake(0, (_scrollView.contentSize.height - self.scrollbar.bounds.size.height) * scrollBar.yPosition / (self.scrollbar.bounds.size.height - self.scrollbar.barHeight))];
}

- (void)scrollBarTouchAction:(HWScrollBar *)scrollBar
{
    [UIView animateWithDuration:scrollBar.barMoveDuration animations:^{
        [self.scrollView setContentOffset:CGPointMake(0, (self.scrollView.contentSize.height - self.scrollbar.bounds.size.height) * scrollBar.yPosition / (self.scrollbar.bounds.size.height - self.scrollbar.barHeight))];
    }];
}


// 进入主界面
- (IBAction)openMainViewController:(UIButton *)sender
{
    EMSHomeViewController *homeVC = [[EMSHomeViewController alloc] init];
    [self.navigationController pushViewController:homeVC animated:YES];
    
}


- (IBAction)checkboxClicked:(UIButton *)sender
{
    sender.selected = !sender.isSelected;
    
    // 改变选中的图片状态
    NSString *imageName =
    sender.isSelected? @"ems_checkbox_p":@"ems_checkbox_n";
    self.checkImageView.image = [UIImage imageNamed:imageName];
    self.nextButton.enabled = sender.isSelected;
//    initWithFrame:CGRectMake(0, 0, size.width-60, 1000)
}

#pragma mark -  布局子控件
- (void)subviewLayout
{
    // 设置label和checkedView
    //CGSize size = self.textView.bounds.size;
    //self.textLabel.frame = CGRectMake(0, 0, size.width-60, 1000);
    self.checkedView = self.checkboxContentView;
    [self.checkboxContentView removeFromSuperview];
    [self.scrollView addSubview:self.checkedView];
    [self.scrollView addSubview:_textLabel];
    //CGFloat height = self.checkedView.bounds.size.height;
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    CGSize size = self.scrollView.contentSize;
    CGFloat height = self.checkedView.frame.size.height;
    self.checkedView.center = CGPointMake(size.width*0.5, size.height-height*0.8);
    self.checkedView.x = 0;
    self.checkedView.hidden = NO;
//    [self.checkedView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.left.equalTo(self.textLabel.mas_left).offset(0);
//    make.bottom.equalTo(self.textLabel.mas_bottom).offset(-height);
//    }];

}


#pragma mark - 设置文本
- (void)setupAttributeTextForLabel
{
    
    NSMutableAttributedString *content = [[NSMutableAttributedString alloc] init];
    UIFont *normalFont = [UIFont fontWithName:@"BodyFriendM" size:14];
    UIFont *blueTextFont = [UIFont fontWithName:@"BodyFriendM" size:25];
    UIColor *blue = LLColor(65, 200, 253);
    ;
    
    
    [content appendAttributedString:[@"Electro-Muscle Stimulation(EMS) training은 집중적인 근육자극으로 많은 운동시간을 절약할 수 있는 운동방법으로써 세계에서 가장 효과적인 운동법 중 하나입니다. 본 제품은 몸의 건강상태에 대한 확인이 반드시 선행되어야 합니다. 아래와 같은 질환을 보유하신 분은 전문의와 상담 후 사용하시기 바랍니다.\n\n" attributeStringWithColor:UIColor.whiteColor textFont:normalFont]];
    [content appendAttributedString:[@"1. Heart (심장)\n" attributeStringWithColor:blue textFont:blueTextFont]];
    [content appendAttributedString:[@"- Cardiovascular disease (심혈관질환)\n- Bloodstream problems (혈류문제)\n- High blood pressure(Hypertension) (고혈압)\n- Artificial pacemaker (인공 심장박동기)\n- Internal defibrillator (내부 세동제거기)\n- Person who experienced ‘bypass surgery’ (우회수술 유경험자)\n- Myocardiac infarction (심근경색)\n- Arthrosclerosis (동맥경화증)\n- Angina pectoris (협심증)\n- Sick-Sinus-Syndrome (동기능부전증후군)\n- Carotid-sinus syndrome (경동맥동증후군)\n\n" attributeStringWithColor:UIColor.whiteColor textFont:normalFont]];
    
    [content appendAttributedString:[@"2. Skin (스킨)\n" attributeStringWithColor:blue textFont:blueTextFont]];
    [content appendAttributedString:[@"- Neurodermatitis (신경피부염)\n- Psoriasis (건선)\n- Generally dry skin (일반적으로 건성 피부)\n- Open skin injuries, eczema, sunburn etc. under or near the electrodes\n(전극 밑 또는 근처에서 피부손상, 습진, 일광화상 등)\n\n" attributeStringWithColor:UIColor.whiteColor textFont:normalFont]];

    [content appendAttributedString:[@"3. Metabolism (신진대사)\n" attributeStringWithColor:blue textFont:blueTextFont]];
    [content appendAttributedString:[@"- Diabetes mellitus (당뇨병)\n- Gall bladder or kidney stones (담석 또는 신장결석)\n\n" attributeStringWithColor:UIColor.whiteColor textFont:normalFont]];

    [content appendAttributedString:[@"4. Implants (임플란트)\n" attributeStringWithColor:blue textFont:blueTextFont]];
    [content appendAttributedString:[@"- Metal implants (금속 임플란트)\n- Piercings under or near the electrodes (전극 밑 또는 근처의 피어싱)\n\n" attributeStringWithColor:UIColor.whiteColor textFont:normalFont]];
    
    [content appendAttributedString:[@"5. Neurology (신경계)\n" attributeStringWithColor:blue textFont:blueTextFont]];
    [content appendAttributedString:[@"- Epilepsy (간질)\n- Parkinson is disease (파킨슨병)\n- Multiple sclerosis (다발성경화증)\n- Amyotrophic Lateral Sclerosis (근위축성측삭경화증, 루게릭병)\n- Spastic spinal paralysis (강직성척수마비)\n- Severe migraine (심한 편두통)\n- Orientation disturbances (방향장애)\n\n" attributeStringWithColor:UIColor.whiteColor textFont:normalFont]];
    
    [content appendAttributedString:[@"6. Bleeding (출혈)\n" attributeStringWithColor:blue textFont:blueTextFont]];
    [content appendAttributedString:[@"- Hemophilia (increased bleeding tendency) (혈우병, 출혈 경향이 있는 자)\n- Severe circulatory disorders (심한 순환기장애)\n- bleeding (출혈)\n- Thrombosis (혈전증)\n\n" attributeStringWithColor:UIColor.whiteColor textFont:normalFont]];
    
    [content appendAttributedString:[@"7. Internal Medicine (내과)\n" attributeStringWithColor:blue textFont:blueTextFont]];
    [content appendAttributedString:[@"- Tumors (종양)\n- Cancer (암)\n- Operation in the last 6 months (최근 6개월 내에 수술)\n- Stroke (뇌졸증)\n- Lymphedema (림프부종)\n- Acute inflammation (급성염증)\n- Inflammation of the leg veins, varicose veins (다리정맥 염증, 이상 정맥류)\n- Effusions in the body cavities (eg: pleural effusion, ascites)\n&#12288;(체강삼출) (예: 흉막삼출액, 복수)\n- Fever (발열)\n\n" attributeStringWithColor:UIColor.whiteColor textFont:normalFont]];
    
    [content appendAttributedString:[@"8. Gravidity (임신)\n" attributeStringWithColor:blue textFont:blueTextFont]];
    [content appendAttributedString:[@"- All pregnant women (모든 임산부)\n\n" attributeStringWithColor:UIColor.whiteColor textFont:normalFont]];
    [content appendAttributedString:[@"9. Orthopedics (정형외과학)\n" attributeStringWithColor:blue textFont:blueTextFont]];
    [content appendAttributedString:[@"- Orthopedic complaints (정형외과적 통증)\n- Diseases that complicate sportive activities (스포츠 활동으로 악화된 질병)\n- Rheumatic diseases (류마티스 질환)\n- (Articular)gout ((관절)통풍)\n- Osteoporosis (골다공증)\n- Progressive muscle dystrophia (진행성 근이영양증)\n- Tendinopathy(sinews disease) (건염(근력증))\n- Spinal disk syndrom (척추디스크)\n- Disk prolapse (디스크 탈출증)\n- Fractures (골절)\n\n" attributeStringWithColor:UIColor.whiteColor textFont:normalFont]];
    
    [content appendAttributedString:[@"10. Others (기타)\n" attributeStringWithColor:blue textFont:blueTextFont]];
    [content appendAttributedString:[@"- Influence of alcohol (주류에 의한 중독 및 증상)\n- Influence of drugs (마약류 및 약물에 의한 중독 및 증상)\n- Anxiety of electricity (전기자극에 대한 불안)\n\n\n\n" attributeStringWithColor:UIColor.whiteColor textFont:normalFont]];
    
    self.textLabel.attributedText = content;
}
@end
