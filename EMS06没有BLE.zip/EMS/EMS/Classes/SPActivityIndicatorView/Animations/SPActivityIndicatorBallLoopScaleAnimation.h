//
//  SPActivityIndicatorBallLoopScaleAnimation.h
//  SPActivityIndicatorView
//
//  Created by 乐升平 on 2018/11/19.
//  Copyright © 2018 乐升平. All rights reserved.
//

#import "SPActivityIndicatorAnimation.h"

NS_ASSUME_NONNULL_BEGIN

@interface SPActivityIndicatorBallLoopScaleAnimation : SPActivityIndicatorAnimation

@end

NS_ASSUME_NONNULL_END
