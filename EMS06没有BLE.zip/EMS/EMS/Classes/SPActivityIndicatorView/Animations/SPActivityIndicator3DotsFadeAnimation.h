//
//  SPActivityIndicator3DotsFadeAnimation.h
//  SPActivityIndicatorView
//
//  Created by 乐升平 on 2018/11/19.
//  Copyright © 2018 乐升平. All rights reserved.
//  这个动画类似于微信王者荣耀中网络卡顿时的加载动画

#import "SPActivityIndicatorAnimation.h"

NS_ASSUME_NONNULL_BEGIN

@interface SPActivityIndicator3DotsFadeAnimation : SPActivityIndicatorAnimation

@end

NS_ASSUME_NONNULL_END
