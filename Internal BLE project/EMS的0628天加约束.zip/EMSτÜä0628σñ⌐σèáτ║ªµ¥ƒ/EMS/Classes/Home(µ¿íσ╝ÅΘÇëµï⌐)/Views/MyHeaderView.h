//
//  MyHeaderView.h
//  EMS
//
//  Created by 柏霖尹 on 2019/6/24.
//  Copyright © 2019 work. All rights reserved.
//

#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN
@class MyHeaderView, EMSGroup;
@protocol MyHeaderViewDelegate <NSObject>
@optional
- (void)headerViewDidClickedNameView:(MyHeaderView *)headerView;
@end

@interface MyHeaderView : UITableViewHeaderFooterView

+ (instancetype)headerViewWithTableView:(UITableView *)tableView;

@property (nonatomic, strong) EMSGroup *group;

@property (nonatomic, weak) id<MyHeaderViewDelegate> delegate;
@property (nonatomic, assign, getter=isSelectedHead) BOOL selectedHead; // 选中这个作出响应
@property (nonatomic, strong) UIImageView *bgImageView;
@end

NS_ASSUME_NONNULL_END
