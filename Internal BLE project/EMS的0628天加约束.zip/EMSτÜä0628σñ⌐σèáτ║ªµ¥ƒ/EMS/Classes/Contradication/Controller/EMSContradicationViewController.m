//
//  EMSContradicationViewController.m
//  EMS
//
//  Created by 柏霖尹 on 2019/6/22.
//  Copyright © 2019 work. All rights reserved.
//

#import "EMSContradicationViewController.h"
#import "HWScrollBar.h"
#import "MainViewController.h"
#import "EMSNavigationViewController.h"
@interface EMSContradicationViewController ()<UIScrollViewDelegate, HWScrollBarDelegate, UITextViewDelegate>
@property (weak, nonatomic) IBOutlet UIButton *nextButton;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (nonatomic, strong) UIView *checkedView;
@property (nonatomic, strong) UILabel *textLabel;
//  自定义滚动条
#warning scrollBar
@property (strong, nonatomic) HWScrollBar *scrollbar;
- (IBAction)openMainViewController:(UIButton *)sender;

@property (weak, nonatomic) IBOutlet UIImageView *checkImageView;
@property (weak, nonatomic) IBOutlet UIView *checkboxContentView;
// 同意复选框点击的方法
- (IBAction)checkboxClicked:(id)sender;



@end

@implementation EMSContradicationViewController
#pragma mark - Lifecycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"Contraindication-韩文";
    
    [self setupScrollLabel];
    
    self.navigationController.navigationBar.translucent = YES;
}

- (void)setupScrollLabel
{
    // 设置scrollView的属性
    self.scrollView.indicatorStyle = UIScrollViewIndicatorStyleWhite;
    self.scrollView.delegate = self;

    // 设置文本框的尺寸
    UILabel *label = [[UILabel alloc] init];
    label.numberOfLines = 0;
    [self.scrollView addSubview:label];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.scrollView);
        make.width.equalTo(self.scrollView);
    }];
    self.textLabel = label;
    
    NSString *content = @"Electron-Muscle Simulation（EMS） training 韩文\n韩文\n韩文\n 1.Heart\n\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n2.Heart\n\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n3.Heart\n\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n4.Heart\n\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n-韩文\n\n\n\n";

    NSMutableAttributedString *attrString = [[NSMutableAttributedString alloc] initWithString:content];
    
    // 设置普通字体的颜色
    [attrString addAttributes:@{NSFontAttributeName: [UIFont systemFontOfSize:14],NSForegroundColorAttributeName: [UIColor whiteColor]} range:NSMakeRange(0, content.length)];
    
    for (int i=1; i<=4; i++)
    {
        NSRange blueTextRange = [content rangeOfString:[NSString stringWithFormat:@"%d.Heart", i]];
        [attrString addAttributes:@{NSFontAttributeName: [UIFont systemFontOfSize:20],NSForegroundColorAttributeName: LLColor(65, 200, 253)} range:blueTextRange];
        self.textLabel.attributedText = attrString;
        
    }
    [self subviewLayout];
    
}


- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self setupScrollBar];
}


- (void)setupScrollBar
{
    self.scrollView.showsVerticalScrollIndicator = NO;
    // 确定 autolayout的控件frame
    //    LLog(@"%@", NSStringFromCGRect(self.textView.frame));
    //滚动展示条
    HWScrollBar *bar = [[HWScrollBar alloc] initWithFrame:CGRectMake(CGRectGetMaxX(_scrollView.frame), CGRectGetMinY(_scrollView.frame), 2, _scrollView.bounds.size.height)];
    bar.foreColor = [UIColor whiteColor];
    bar.userInteractionEnabled = NO;
    [self.view addSubview:bar];
    self.scrollbar = bar;
}

#pragma mark - ScrollView 代理方法
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    //更新滚动条位置
    self.scrollbar.yPosition = (self.scrollbar.bounds.size.height - self.scrollbar.barHeight) * scrollView.contentOffset.y / (scrollView.contentSize.height - self.scrollbar.bounds.size.height);
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    // 开始滚动textview
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        //更新滚动条高度
        if (self.scrollView.contentSize.height <= self.scrollView.bounds.size.height)
        {
            self.scrollbar.barHeight = self.scrollView.bounds.size.height;
        }
        else
        {
            self.scrollbar.barHeight = pow(self.scrollView.bounds.size.height, 2) / self.scrollView.contentSize.height;
        }
        
        
        //更新滚动条Y向位置
        self.scrollbar.yPosition = (self.scrollbar.bounds.size.height - self.scrollbar.barHeight) * self.scrollView.contentOffset.y / (self.scrollView.contentSize.height - self.scrollbar.bounds.size.height);
    });
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - Layout subviews

#pragma mark - SXScrollBarDelegate
- (void)scrollBarDidScroll:(HWScrollBar *)scrollBar
{
    [self.scrollView setContentOffset:CGPointMake(0, (_scrollView.contentSize.height - self.scrollbar.bounds.size.height) * scrollBar.yPosition / (self.scrollbar.bounds.size.height - self.scrollbar.barHeight))];
}

- (void)scrollBarTouchAction:(HWScrollBar *)scrollBar
{
    [UIView animateWithDuration:scrollBar.barMoveDuration animations:^{
        [self.scrollView setContentOffset:CGPointMake(0, (self.scrollView.contentSize.height - self.scrollbar.bounds.size.height) * scrollBar.yPosition / (self.scrollbar.bounds.size.height - self.scrollbar.barHeight))];
    }];
}


// 进入主界面
- (IBAction)openMainViewController:(UIButton *)sender
{
    EMSHomeViewController *homeVC = [[EMSHomeViewController alloc] init];
    [self.navigationController pushViewController:homeVC animated:YES];
    
}


- (IBAction)checkboxClicked:(UIButton *)sender
{
    sender.selected = !sender.isSelected;
    
    // 改变选中的图片状态
    NSString *imageName =
    sender.isSelected? @"ems_checkbox_p":@"ems_checkbox_n";
    self.checkImageView.image = [UIImage imageNamed:imageName];
    self.nextButton.enabled = sender.isSelected;
//    initWithFrame:CGRectMake(0, 0, size.width-60, 1000)
}

#pragma mark -  布局子控件
- (void)subviewLayout
{
    // 设置label和checkedView
    //CGSize size = self.textView.bounds.size;
    //self.textLabel.frame = CGRectMake(0, 0, size.width-60, 1000);
    self.checkedView = self.checkboxContentView;
    [self.checkboxContentView removeFromSuperview];
    [self.scrollView addSubview:self.checkedView];
    [self.scrollView addSubview:_textLabel];
    CGFloat height = self.checkedView.bounds.size.height;
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    CGSize size = self.scrollView.contentSize;
    CGFloat height = self.checkedView.frame.size.height;
    self.checkedView.center = CGPointMake(size.width*0.5, size.height-height*0.8);
    self.checkedView.x = 0;
    self.checkedView.hidden = NO;
//    [self.checkedView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.left.equalTo(self.textLabel.mas_left).offset(0);
//    make.bottom.equalTo(self.textLabel.mas_bottom).offset(-height);
//    }];

}
@end
