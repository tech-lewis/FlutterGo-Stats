//
//  EMSSystemViewController.h
//  EMS
//
//  Created by 柏霖尹 on 2019/6/26.
//  Copyright © 2019 work. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface EMSSystemViewController : UIViewController
@property (weak, nonatomic) UIImageView *listLineView;
@property (nonatomic, copy) NSString *selectName;
@property (nonatomic, assign) BOOL isMaleGender; //is男性 否则是女性
@property (nonatomic, copy) NSArray *modelDictArray; // 上一个页面选择的模型字典

@end

NS_ASSUME_NONNULL_END
