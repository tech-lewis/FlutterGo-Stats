//
//  EMSHomeViewController.m
//  EMS
//
//  Created by 柏霖尹 on 2019/6/24.
//  Copyright © 2019 work. All rights reserved.
//

#import "EMSHomeViewController.h"
#import "EMSMenuModel.h"
#import "EMSGroup.h"
#import "MyHeaderView.h"
#import "UIImage+Extension.h"
#import "EMSSystemViewController.h"

// 判断性别的宏定义
#define kMan @"man"
#define kWoman @"woman"
@interface EMSHomeViewController ()<UITableViewDelegate, UITableViewDataSource, MyHeaderViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *menuTable;
@property (nonatomic, strong) NSArray *groups;
@property (weak, nonatomic) IBOutlet UIView *contentView;
@property (nonatomic, strong) MyHeaderView *currentSelSection; // 当前选择的头索引, 默认选中第一个
@property (nonatomic, strong) UITableViewCell *currentCell;
@property (nonatomic, copy) NSString * genderRadioButton;
@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *radioButtons;

// ContentView内的子控件
@property (weak, nonatomic) IBOutlet UILabel *modeNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *descriptionLabel;


- (IBAction)genderButtonClicked:(UIButton *)sender;
@end

@implementation EMSHomeViewController

#pragma mark - TableView Cell
#pragma mark - Lifecycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.

    self.title = @"EMS 模式选择界面";
    self.genderRadioButton = kMan;
    [self setupMenuTableView];

}

- (void)setupMenuTableView
{
    self.menuTable.backgroundColor = [UIColor clearColor];
    self.menuTable.delegate = self;
    self.menuTable.separatorStyle = UITableViewCellSeparatorStyleNone;
}

- (NSArray *)groups
{
    if (_groups == nil)
    {
        NSArray *dictArray = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"menus.plist" ofType:nil]];
        
        NSMutableArray *groupArray = [NSMutableArray array];
        for (NSDictionary *dict in dictArray) {
            EMSGroup *group = [EMSGroup groupWithDict:dict];
            [groupArray addObject:group];
            
        }
        
        _groups = groupArray;
    }
    return _groups;
}

- (BOOL)prefersStatusBarHidden
{
    return YES;
}
//- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    static NSString *ID = @"menuCell";
//    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
//    if (cell == nil)
//    {
//        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:ID];
//        [cell.textLabel setTextColor:[UIColor whiteColor]];
//        cell.backgroundColor = [UIColor clearColor];
//    }
//    // setup cell...
//    cell.textLabel.text = @"菜单";
//    return cell;
//}


#pragma mark - 数据源方法
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.groups.count;
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    EMSGroup *group = self.groups[section];
    if(section != 1) return group.menus.count;
    return (group.isOpened ? group.menus.count : 0);
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *ID = @"menuCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:ID];
        [cell.textLabel setTextColor:[UIColor whiteColor]];
        cell.backgroundColor = [UIColor clearColor];
    }
    //EMSMenuCell *cell = [EMSMenuCell cellWithTableView:tableView];
    UIImageView *selectedImage = [[UIImageView alloc] init];
    if (indexPath.section == 1)
    {
        cell.textLabel.highlightedTextColor = [UIColor blackColor];
        selectedImage.image = [UIImage imageNamed:@"ems_main_sublist01_sel"];
    }
    else
    {
        cell.textLabel.highlightedTextColor = LLColor(65, 200, 253);
        selectedImage.image = [UIImage imageNamed:@"ems_main_list01_sel"];
    }
    cell.selectedBackgroundView = selectedImage;
    // 2.设置cell的数据
    EMSGroup *group = self.groups[indexPath.section];
    EMSMenuModel *data = group.menus[indexPath.row];
    cell.textLabel.text = data.name;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        // 设置第一个header默认为选中状态
        if(indexPath.row ==0&& indexPath.section ==0)
        [self.menuTable selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
    });
    return cell;
}

/**
 *  返回每一组需要显示的头部标题(字符出纳)
 */
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    
    if(section != 1) return nil;
    // 1.创建头部控件
    MyHeaderView *header = [MyHeaderView headerViewWithTableView:tableView];
    header.delegate = self;
    
    // 2.给header设置数据(给header传递模型)
    header.group = self.groups[section];

    return header;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"%d--s:%d", indexPath.row, indexPath.section);
    
    // 设置选中后的文字颜色
    UITableViewCell *selectedCell = [tableView cellForRowAtIndexPath:indexPath];
    
    
    // 如果点击的最后一个按钮就进入收藏界面
    if(indexPath.section ==2& indexPath.row ==3)
    {
#warning 进入收藏界面
        
    }
    else
    {
        [self selectedCellAction:selectedCell];
    }
    
}
- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section
{
    if ([view isKindOfClass:[UITableViewHeaderFooterView class]])
    {
        ((UITableViewHeaderFooterView *)view).backgroundView.backgroundColor = [UIColor clearColor];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if(section != 1) return 0.1;
    return 50.0;
}

- (CGFloat)tableView:(UITableView* )tableView heightForFooterInSection:(NSInteger)section
{
    return 1.0;
}

// 设置cell的不同高度
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section != 1) return 50.0;
        
    return 40.0;
}
#pragma mark - headerView 点击时的代理方法
/**
 *  点击了headerView上面的名字按钮时就会调用
 */
- (void)headerViewDidClickedNameView:(MyHeaderView *)headerView
{
    [self.menuTable reloadData];
    // 处理点击事件和修改状态
    NSLog(@"%@", headerView.group.name);
    // 3 step
    //self.currentSelSection.bgImageView.image = nil;
    
    BOOL isOpen = headerView.group.isOpened;
    if (isOpen)
    {
        //选中第一行
        NSIndexPath *selectIndex = [NSIndexPath indexPathForRow:0 inSection:1];
        [self.menuTable selectRowAtIndexPath:selectIndex animated:NO scrollPosition:UITableViewScrollPositionNone];
        headerView.bgImageView.image = [UIImage imageNamed:@"ems_main_list01_sel"];
        
    }
    else
    {
        headerView.bgImageView.image = [UIImage new];
        
    }
    
    //self.currentSelSection = headerView;
    
}

- (void)selectedCellAction:(UITableViewCell *)cell
{
    NSString *name= cell.textLabel.text;
    self.modeNameLabel.text = [NSString stringWithFormat:@"%@(对应韩语)", name];
    
    self.descriptionLabel.text =[NSString stringWithFormat:@"%@(对应韩语描述信息韩语描述信息韩语描述信息韩语描述信息)", name];

}
#warning 补充性别处理代码
#pragma mark - 单选按钮的点击处理
- (IBAction)genderButtonClicked:(UIButton *)sender
{
    for (UIButton *btn in self.radioButtons)
    {
         btn.selected = NO;
    }
    sender.selected = YES;
    NSString *btnTitle = [sender titleForState:UIControlStateDisabled];
    if([btnTitle isEqualToString:kMan]) self.genderRadioButton = kMan;
    if([btnTitle isEqualToString:kWoman]) self.genderRadioButton = kWoman;
    
}


- (IBAction)nextButtonClicked:(id)sender
{
    EMSSystemViewController *systemControlVC = [[EMSSystemViewController alloc] init];
    systemControlVC.title = @"EMS 衣服调节界面";
    systemControlVC.isMaleGender= [_genderRadioButton isEqualToString:kMan]? YES:NO;
    [self.navigationController pushViewController:systemControlVC animated:YES];
}
@end
