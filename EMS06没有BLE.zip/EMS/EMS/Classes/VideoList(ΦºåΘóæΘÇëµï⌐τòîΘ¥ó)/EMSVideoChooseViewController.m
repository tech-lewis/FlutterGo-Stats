//
//  EMSVideoChooseViewController.m
//  EMS
//
//  Copyright © 2019 work. All rights reserved.
//

#import "EMSVideoChooseViewController.h"
#import "UIImage+Extension.h"
#import "EMSViedoListCell.h"
#import "HWScrollBar.h"
#import "EMSVideoModel.h"
#import "EMSVideoPlayController.h"
@interface EMSVideoChooseViewController ()<UITableViewDelegate, UITableViewDataSource, UIScrollViewDelegate, HWScrollBarDelegate, UITextViewDelegate>
@property (weak, nonatomic) IBOutlet UIButton *nextButton;

//  自定义滚动条
@property (weak, nonatomic) IBOutlet UITextView *textView;
@property (nonatomic, strong) NSMutableArray *selectItemArray;
@property (strong, nonatomic) HWScrollBar *textScrollbar;
@property (strong, nonatomic) HWScrollBar *scrollbar;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIView *tableBgView;

// 存放数组的名字
@property (nonatomic, copy) NSArray *nameArray;
@property (nonatomic, copy) NSMutableArray *selectNameArray;
/** 用于显示视频列表中的视频*/
@property (weak, nonatomic) IBOutlet UILabel *multiNameLabel;

@end

@implementation EMSVideoChooseViewController

#pragma mark - Lazy init
- (NSMutableArray *)selectItemArray
{
    if(_selectItemArray == nil)
    {
        _selectItemArray = [NSMutableArray arrayWithCapacity:4];
    }

    return _selectItemArray;
}
- (NSMutableArray *)selectNameArray
{
    if(_selectNameArray == nil)
    {
        _selectNameArray = [NSMutableArray arrayWithCapacity:4];
    }
    return _selectNameArray;
}

#pragma UI 更新
- (void)updateVideoTextLabel
{
    self.multiNameLabel.text = [_selectNameArray componentsJoinedByString:@", "];
}
- (void)updateTextViewContent
{
    UIColor *blueText = LLColor(65, 200, 253);
    UIFont *font = [UIFont fontWithName:@"BodyFriendM" size:15];
    NSMutableAttributedString *content = [[NSMutableAttributedString alloc] init];
    for (EMSVideoModel *model in self.selectItemArray)
    {
        NSString *title = [NSString stringWithFormat:@"%@\n", [[model.descriptionStr componentsSeparatedByString:@";"] firstObject]];
        NSString *desc =  [NSString stringWithFormat:@"%@\n", [[model.descriptionStr componentsSeparatedByString:@";"] lastObject]];
        
        
        
        [content appendAttributedString:[title attributeStringWithColor:blueText textFont:font]];
        [content appendAttributedString:[desc attributeStringWithColor:UIColor.whiteColor textFont:font]];
    }
    
    self.textView.attributedText = content;
}

- (void)setModels:(NSArray<EMSVideoModel *> *)models
{
    _models = models;
    // 设置名字数组
    self.nameArray = models;
}
#pragma mark - Lifecycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
    [self setupUI];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self setupScrollBar];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    [self.scrollbar removeFromSuperview];
    self.scrollbar = nil;
}


- (void)setupUI
{
    // 设置底部文本栏的拉伸背景图
    self.multiNameLabel.backgroundColor = [UIColor colorWithRed:75/255 green:75/255 blue:75/255 alpha:0.2];
    self.multiNameLabel.layer.cornerRadius = 10;
    self.multiNameLabel.layer.masksToBounds = YES;
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    // 添加滚动条setupScrollBar
    self.tableView.showsVerticalScrollIndicator = NO;
    // 确定 autolayout的控件frame
    //    LLog(@"%@", NSStringFromCGRect(self.textView.frame));
}

#pragma mark - TableView 代理和数据源方法
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    EMSViedoListCell *cell = [EMSViedoListCell cellWithTableView:tableView];
    // setup cell...
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    // 检查模型的选中情况  修改label的文字
    cell.model = self.nameArray[indexPath.row];

    return cell;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.nameArray.count;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    EMSViedoListCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    
    EMSVideoModel *model = self.nameArray[indexPath.row];
    //    model.isSelect = !model.isSelect;
    model.isSelect = !model.isSelect;
    cell.model = model;
    
    // 选中就加到数组 否则移除
    if(model.isSelect)
    {
        if(_selectItemArray.count < 4)
        {
            [self.selectNameArray addObject:[NSString stringWithFormat:@"%ld", indexPath.row]];
            
            [self.selectItemArray addObject:model];
            [self updateTextViewContent];
            [self updateVideoTextLabel];
        }
        else
        {
            // 弹窗警告
#warning alert Window
            NSLog(@"최대 4개 영상까지 선택 가능합니다.");
        }
    }
    else
    {
        [self.selectItemArray removeObject:model];
        [self.selectNameArray removeObject:[NSString stringWithFormat:@"%ld", indexPath.row]];
        [self updateTextViewContent];
        [self updateVideoTextLabel];
    }
    
    
    // 控制按钮的点击 选择了某个项目之后才可以跳转到视频播放的界面
    self.nextButton.enabled = (_selectNameArray.count >0);
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60.0;
}
#pragma mark - Navigation
//
- (void)setupScrollBar
{
    self.tableView.showsVerticalScrollIndicator = NO;
    // 确定 autolayout的控件frame滚动展示条
    HWScrollBar *bar = [[HWScrollBar alloc] initWithFrame:CGRectMake(CGRectGetMaxX(_tableView.frame), CGRectGetMinY(_tableView.frame), 2, _tableView.bounds.size.height)];
    bar.foreColor = [UIColor whiteColor];
    bar.userInteractionEnabled = NO;
    [self.tableBgView addSubview:bar];
    self.scrollbar = bar;
}

#pragma mark - ScrollView 代理方法
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    //更新滚动条位置
    self.scrollbar.yPosition = (self.scrollbar.bounds.size.height - self.scrollbar.barHeight) * scrollView.contentOffset.y / (scrollView.contentSize.height - self.scrollbar.bounds.size.height);
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    // 开始滚动textview
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        //更新滚动条高度
        if (self.tableView.contentSize.height <= self.tableView.bounds.size.height)
        {
            self.scrollbar.barHeight = self.tableView.bounds.size.height;
        }
        else
        {
            self.scrollbar.barHeight = pow(self.tableView.bounds.size.height, 2) / self.tableView.contentSize.height;
        }
        
        
        //更新滚动条Y向位置
        self.scrollbar.yPosition = (self.scrollbar.bounds.size.height - self.scrollbar.barHeight) * self.tableView.contentOffset.y / (self.tableView.contentSize.height - self.scrollbar.bounds.size.height);
    });
}
/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */


#pragma mark - ScrollBarDelegate
- (void)scrollBarDidScroll:(HWScrollBar *)scrollBar
{
    [self.tableView setContentOffset:CGPointMake(0, (self.tableView.contentSize.height - self.scrollbar.bounds.size.height) * scrollBar.yPosition / (self.scrollbar.bounds.size.height - self.scrollbar.barHeight))];
}

- (void)scrollBarTouchAction:(HWScrollBar *)scrollBar
{
    [UIView animateWithDuration:scrollBar.barMoveDuration animations:^{
        [self.tableView setContentOffset:CGPointMake(0, (self.tableView.contentSize.height - self.scrollbar.bounds.size.height) * scrollBar.yPosition / (self.scrollbar.bounds.size.height - self.scrollbar.barHeight))];
    }];
}

//- (void)viewDidLayoutSubviews
//{
//    self.scrollbar.frame = CGRectMake(CGRectGetMaxX(self.tableView.frame), CGRectGetMinY(self.tableView.frame), 2, self.tableView.bounds.size.height);
//}
- (IBAction)nextButtonAction:(id)sender
{
    EMSVideoPlayController *videoVC = [[EMSVideoPlayController alloc] init];
    videoVC.title = @"EMS 트레이닝";
    
    [self.navigationController pushViewController:videoVC animated:YES];
}
@end
