//
//  EMSSystemViewController.m
//  EMS
//
//  Created by 柏霖尹 on 2019/6/26.
//  Copyright © 2019 work. All rights reserved.
//

#import "EMSSystemViewController.h"
#import "SystemControlMaleView.h"

@interface EMSSystemViewController (){
    UIView *clotheView;
}
@property (weak, nonatomic) IBOutlet UIView *clotheContentView;

@end

@implementation EMSSystemViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setupChileViews];
}

- (void)setupChileViews
{
    self.listLineView.image = [UIImage resizedImageWithName:@"ems_list_line"];
     clotheView=nil;
    if(self.isMaleGender) clotheView = [SystemControlMaleView systemControlMaleView];
    
    
    clotheView.frame=CGRectMake(0, 0, self.clotheContentView.frame.size.width,self.clotheContentView.height);
    
    
    
    [self.clotheContentView addSubview:clotheView];
    //[clotheView performSelector:@selector(selectAllButtons)];
    
    
}

-(void)viewDidLayoutSubviews{
    [super viewDidLayoutSubviews];
    clotheView.frame=CGRectMake(0, 0, self.clotheContentView.frame.size.width,self.clotheContentView.height);
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
