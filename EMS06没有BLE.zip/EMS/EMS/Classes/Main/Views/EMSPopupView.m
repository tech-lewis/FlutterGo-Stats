//
//  EMSPopupView.m
//  EMS
//
//  Created by 柏霖尹 on 2019/7/1.
//  Copyright © 2019 work. All rights reserved.
//

#import "EMSPopupView.h"
#import "SPActivityIndicatorView.h"
#define kAlertTextFont [UIFont systemFontOfSize:21]
@interface EMSPopupView()
@property (nonatomic, weak) UIImageView *imageView;
@property (nonatomic, weak) UILabel *label;
@property (nonatomic, weak) UILabel *nameLabel;
@end


@implementation EMSPopupView

+(instancetype)popupViewWithConnectedDeviceName:(NSString *)name;
{
    
    CGFloat height = 150;
    CGFloat width = 349;
    EMSPopupView *view = [[self alloc] init];
    view.frame = CGRectMake(0, 0, width, height);
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ems_popup_bg01"]];
    imageView.frame = CGRectMake(0, 0, width, height);
    view.imageView = imageView;
    [view addSubview:imageView];
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, 50)];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [titleLabel setFont:kAlertTextFont];
    [titleLabel setTextColor:[UIColor whiteColor]];
    view.label = titleLabel;
    [view addSubview:titleLabel];
    
    UILabel *nameLabel = [[UILabel alloc] init];
    nameLabel.textAlignment = NSTextAlignmentCenter;
    [nameLabel setFont:kAlertTextFont];
    nameLabel.text = name;
    [nameLabel sizeToFit];
    nameLabel.center = view.center;
    nameLabel.y = CGRectGetMaxY(titleLabel.frame);
    [nameLabel setTextColor:[UIColor whiteColor]];
    view.nameLabel = nameLabel;
    [view addSubview:nameLabel];
    
    
#warning 修改正确的文本
    view.label.text = @"连接成功(韩语)";
    return view;
}

+ (instancetype)popupViewWithDeviceName:(NSString *)name;
{
    CGFloat height = 150;
    CGFloat width = 349;
    EMSPopupView *view = [[self alloc] init];
    view.frame = CGRectMake(0, 0, width, height);
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ems_popup_bg01"]];
    imageView.frame = CGRectMake(0, 0, width, height);
    view.imageView = imageView;
    [view addSubview:imageView];
    
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, 90)];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [titleLabel setFont:kAlertTextFont];
    [titleLabel setTextColor:[UIColor whiteColor]];
    view.label = titleLabel;
    [view addSubview:titleLabel];
    
    UILabel *nameLabel = [[UILabel alloc] init];
    nameLabel.textAlignment = NSTextAlignmentCenter;
    [nameLabel setFont:kAlertTextFont];
    nameLabel.text = name;
    [nameLabel sizeToFit];
    nameLabel.center = view.center;
    nameLabel.y = CGRectGetMaxY(titleLabel.frame);
    [nameLabel setTextColor:[UIColor whiteColor]];
    view.nameLabel = nameLabel;
    [view addSubview:nameLabel];
    
    
    // 设置spinner
    UIImageView *spinner = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ems_circle"]];
    spinner.frame = CGRectMake(0, 0, 20, 20);
    spinner.center = nameLabel.center;
    spinner.x = CGRectGetMinX(nameLabel.frame)-25;
    [view addSubview:spinner];
    [self startAnimationWithImageView:spinner];
    
    CABasicAnimation *animation =  [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    animation.fromValue = [NSNumber numberWithFloat:0.f];
    animation.toValue =  [NSNumber numberWithFloat: M_PI *2];
    animation.duration  = 1;
    animation.autoreverses = NO;
    animation.fillMode =kCAFillModeForwards;
    animation.repeatCount = MAXFLOAT;
    [spinner.layer addAnimation:animation forKey:nil];
    
    
#warning 修改正确的文本
    view.label.text = @"연결 중입니다. 기다려 주세요.";
    return view;
}


+ (void)startAnimationWithImageView:(UIImageView *)imageView
{
    CABasicAnimation *animation =  [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    
    //默认是顺时针效果，若将fromValue和toValue的值互换，则为逆时针效果
    animation.fromValue = [NSNumber numberWithFloat:0.f];
    animation.toValue =  [NSNumber numberWithFloat: M_PI *2];
    animation.duration  = 1;
    animation.autoreverses = NO;
    animation.fillMode =kCAFillModeForwards;
    animation.repeatCount = MAXFLOAT; //如果这里想设置成一直自旋转，可以设置为MAXFLOAT，否则设置具体的数值则代表执行多少次
    [imageView.layer addAnimation:animation forKey:nil];
    
}
- (instancetype)init
{
    self = [super init];
    if (self)
    {
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        // init子控件
//
//        UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ems_popup_bg01"]];
//        //495*213
//        self.imageView = imageView;
//        [self addSubview:imageView];
//
//        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, 50)];
//        titleLabel.textAlignment = NSTextAlignmentCenter;
//        [titleLabel setFont:[UIFont systemFontOfSize:30]];
//        [titleLabel setTextColor:[UIColor whiteColor]];
//        self.label = titleLabel;
//        [imageView addSubview:titleLabel];
//
//        UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 50, frame.size.width, 50)];
//        nameLabel.textAlignment = NSTextAlignmentCenter;
//        [nameLabel setFont:[UIFont systemFontOfSize:30]];
//        [nameLabel setTextColor:[UIColor whiteColor]];
//        self.nameLabel = nameLabel;
//        [imageView addSubview:nameLabel];
        
    }
    return self;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
