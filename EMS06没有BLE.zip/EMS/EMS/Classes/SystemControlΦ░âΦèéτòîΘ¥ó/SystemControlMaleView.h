//
//  SystemControlMaleView.h
//  EMS
//
//  Created by 柏霖尹 on 2019/6/27.
//  Copyright © 2019 work. All rights reserved.
//

#import <UIKit/UIKit.h>
#define kHighValue @"40"
#define kMiddleValue @"20"
#define kLowValue @"10"
#warning  要注意修改为正确的数字

NS_ASSUME_NONNULL_BEGIN

@interface SystemControlMaleView : UIView
@property (nonatomic, copy, nullable) NSMutableSet * selectButtons;
// 创建试图和全选反选按钮的方法
+ (instancetype)systemControlMaleView;
- (void)selectAllButtons;
- (void)deselectAllButtons;

/** 用于左侧的调节3按钮的 第三个*/
- (void)setAllButtonTitleForLowValue;
/** 用于左侧的调节3按钮的 第2个*/
- (void)setAllButtonTitleForMiddleValue;
/** 用于左侧的调节3按钮的 第1个*/
- (void)setAllButtonTitleForHighValue;

- (void)plusButtonAction;
- (void)minusButtonAction;
@end

NS_ASSUME_NONNULL_END
