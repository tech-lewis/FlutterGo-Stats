//
//  EMSVideoModel.h
//  EMS
//
//  Created by 柏霖尹 on 2019/7/1.
//  Copyright © 2019 work. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface EMSVideoModel : NSObject
@property (nonatomic, copy) NSString *icon;
@property (nonatomic, copy) NSString *descriptionStr;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *selectName;
@property (nonatomic, assign) BOOL isSelect;
+ (instancetype)videoListWithDict:(NSDictionary *)dict;
- (instancetype)initWithDict:(NSDictionary *)dict;
@end
NS_ASSUME_NONNULL_END
