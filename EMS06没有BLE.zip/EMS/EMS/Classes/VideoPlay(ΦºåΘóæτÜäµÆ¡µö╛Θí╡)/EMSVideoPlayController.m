//
//  EMSVideoPlayController.m
//  EMS
//
//  Created by 柏霖尹 on 2019/7/3.
//  Copyright © 2019 work. All rights reserved.
//

#import "EMSVideoPlayController.h"

@interface EMSVideoPlayController ()
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;

@end

@implementation EMSVideoPlayController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self setupUI];
}

- (void)setupUI
{
    // 添加几个view到scroll里面
    
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
