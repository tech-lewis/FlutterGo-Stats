//
//  SystemControlMaleView.m
//  EMS
//
//  Created by 柏霖尹 on 2019/6/27.
//  Copyright © 2019 work. All rights reserved.
//

#import "SystemControlMaleView.h"
#import "UIImageView+Extension.h"

#define kLimited 10
@interface SystemControlMaleView()

/** 左右胸的背景图*/
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *blueView1;
/** 左右手袖的背景图*/
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *blueView2;
/** 左右腹部的背景图*/
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *blueView3;
/** 左右大腿的背景图*/
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *blueView4;

/** rear左右颈部的背景图*/
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *rearBlueView1;
/** rear左右胸的背景图*/
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *rearBlueView2;
/** rear左右腹部的背景图*/
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *rearBlueView3;
/** rear左右腹部的背景图*/
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *rearBlueView4;
/** rear左右大腿的背景图*/
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *rearBlueView5;
/** rear左右腹部的背景图*/
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *rearBlueView6;

@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *buttons;

/** 前后衣服 的容器view*/
@property (weak, nonatomic) IBOutlet UIView *frontView;
@property (weak, nonatomic) IBOutlet UIView *rearView;


@end


@implementation SystemControlMaleView

+(instancetype)systemControlMaleView
{
    NSBundle *bundle = [NSBundle mainBundle];
    // 读取xib文件(会创建xib中的描述的所有对象)
    NSArray *objs = [bundle loadNibNamed:@"SystemControlMaleView" owner:self options:nil];
    SystemControlMaleView *maleView = [objs lastObject];
    
    
    
    return maleView;
}


//- (void)injected
//{
//    NSLog(@"Hot running");
//}
#warning mark - Lazy init
- (NSMutableSet *)selectButtons
{
    if(_selectButtons == nil)
    {
        _selectButtons = [NSMutableSet setWithCapacity:40];
        for (UIButton *button in self.buttons)
        {
            // 放所有按钮的数组
            if(button.isSelected)
            {
                [_selectButtons addObject:button];
            }
        }
    }
    
    return _selectButtons;
}


#pragma mark - 按钮的处理方法
- (void)deselectAllButtons
{
    // 清空集合当中所有按钮
    self.selectButtons = nil;
    
    // 让所有的图片都变成高亮
    [self.blueView1 makeObjectsPerformSelector:@selector(deselectImageView)];
    [self.blueView2 makeObjectsPerformSelector:@selector(deselectImageView)];
    [self.blueView3 makeObjectsPerformSelector:@selector(deselectImageView)];
    [self.blueView4 makeObjectsPerformSelector:@selector(deselectImageView)];
    
    
    [self.rearBlueView1 makeObjectsPerformSelector:@selector(deselectImageView)];
    [self.rearBlueView2 makeObjectsPerformSelector:@selector(deselectImageView)];
    [self.rearBlueView3 makeObjectsPerformSelector:@selector(deselectImageView)];
    [self.rearBlueView4 makeObjectsPerformSelector:@selector(deselectImageView)];
    [self.rearBlueView5 makeObjectsPerformSelector:@selector(deselectImageView)];
    [self.rearBlueView6 makeObjectsPerformSelector:@selector(deselectImageView)];
    
}


- (void)selectAllButtons
{
    
    
    // 将所有的按钮添加到集合当中
    self.selectButtons = [NSMutableSet setWithArray:_buttons];
    
    // 让所有的图片都变成高亮
    [self.blueView1 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
    [self.blueView2 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
    [self.blueView3 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
    [self.blueView4 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
    
    [self.rearBlueView1 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
    [self.rearBlueView2 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
    [self.rearBlueView3 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
    [self.rearBlueView4 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
    [self.rearBlueView5 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
    [self.rearBlueView6 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
}


#pragma mark - 监听按钮的点击事件

- (IBAction)frontButtonAction:(UIButton *)sender
{
    // 左右胸按钮点击处理
    sender.selected = !sender.isSelected;
    
    NSInteger mytag = sender.tag/10;
    if(sender.isSelected)
    {

        // 添加到选中的数组
        [self.selectButtons addObject:[_frontView viewWithTag:(mytag*10)]];
        [self.selectButtons addObject:[_frontView viewWithTag:(mytag*10+1)]];
        
        /////////UI
        // 背景色设置为红色
        switch (mytag) {
            case 1:
                [self.blueView1 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
                break;
            case 2:
                [self.blueView2 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
                break;
            case 3:
                [self.blueView3 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
                break;
            case 4:
                [self.blueView4 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
                break;
            default:
                break;
        }
    }
    else
    {
        // Remove
        [self.selectButtons removeObject:[_frontView viewWithTag:(mytag*10)]];
        [self.selectButtons removeObject:[_frontView viewWithTag:(mytag*10+1)]];
        
        // 背景色设置为蓝色
        switch (mytag)
        {
            case 1:
                [self.blueView1 makeObjectsPerformSelector:@selector(deselectImageView)];
                break;
            case 2:
                [self.blueView2 makeObjectsPerformSelector:@selector(deselectImageView)];
                break;
            case 3:
                [self.blueView3 makeObjectsPerformSelector:@selector(deselectImageView)];
                break;
            case 4:
                [self.blueView4 makeObjectsPerformSelector:@selector(deselectImageView)];
                break;
            default:
                break;
        }
    }
    
}

- (IBAction)rearButtonAction:(UIButton *)sender
{
    // 左右胸按钮点击处理
    sender.selected = !sender.isSelected;
    // 为了区分衣服前后贴片的按钮样式
    NSInteger mytag = sender.tag/100;
    if(sender.isSelected)
    {
        [self.selectButtons addObject:[_rearView viewWithTag:(mytag*100)]];
        [self.selectButtons addObject:[_rearView viewWithTag:(mytag*100+1)]];
        // 背景色设置为红色
        switch (mytag) {
            case 1:
                [self.rearBlueView1 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
                break;
            case 2:
                [self.rearBlueView2 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
                break;
            case 3:
                [self.rearBlueView3 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
                break;
            case 4:
                [self.rearBlueView4 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
                break;
            case 5:
                [self.rearBlueView5 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
                break;
            case 6:
                [self.rearBlueView6 makeObjectsPerformSelector:@selector(hightlightRedImageView)];
                break;
            default:
                break;
        }
    }
    else
    {
        [self.selectButtons removeObject:[_rearView viewWithTag:(mytag*100)]];
        [self.selectButtons removeObject:[_rearView viewWithTag:(mytag*100+1)]];
        // 背景色设置为蓝色
        switch (mytag) {
            case 1:
                [self.rearBlueView1 makeObjectsPerformSelector:@selector(deselectImageView)];
                break;
            case 2:
                [self.rearBlueView2 makeObjectsPerformSelector:@selector(deselectImageView)];
                break;
            case 3:
                [self.rearBlueView3 makeObjectsPerformSelector:@selector(deselectImageView)];
                break;
            case 4:
                [self.rearBlueView4 makeObjectsPerformSelector:@selector(deselectImageView)];
                break;
            case 5:
                [self.rearBlueView5 makeObjectsPerformSelector:@selector(deselectImageView)];
                break;
            case 6:
                [self.rearBlueView6 makeObjectsPerformSelector:@selector(deselectImageView)];
                break;
            default:
                break;
        }
    }
    
}


-(void)layoutSubviews
{
    [super layoutSubviews];
}


#warning 设置 调节按钮的功能 确定数字是否正确
- (void)plusButtonAction
{
    for (UIButton *button in self.selectButtons)
    {
        [self setButtonTitleAddOne:button];
    }
}

- (void)minusButtonAction
{
    for (UIButton *button in self.selectButtons)
    {
        [self setButtonTitleMinusOne:button];
    }
}

- (void)setButtonTitleAddOne:(UIButton *)button
{
    NSString *valueStr = [button titleForState:UIControlStateNormal];
    int value = [valueStr intValue];
    value++;
    [button setTitle:[NSString stringWithFormat:@"%d", value] forState:UIControlStateNormal];
}

- (void)setButtonTitleMinusOne:(UIButton *)button
{
    //
    NSString *valueStr = [button titleForState:UIControlStateNormal];
    
    int value = [valueStr intValue];
    value--;
    if(value<kLimited) value =kLimited;
    [button setTitle:[NSString stringWithFormat:@"%d", value] forState:UIControlStateNormal];
}



- (void)setAlloButtonsTitle:(NSString *)title
{
    for (UIButton *button in self.buttons)
    {
        // 放所有按钮的数组
        [button setTitle:title forState:UIControlStateNormal];
    }
}

- (void)setAllButtonTitleForLowValue
{
    [self setAlloButtonsTitle:kLowValue];
}
- (void)setAllButtonTitleForMiddleValue
{
    [self setAlloButtonsTitle:kMiddleValue];
}

- (void)setAllButtonTitleForHighValue
{
    [self setAlloButtonsTitle:kHighValue];
}
@end
