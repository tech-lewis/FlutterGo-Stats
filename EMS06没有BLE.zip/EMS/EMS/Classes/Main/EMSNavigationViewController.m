//
//  EMSNavigationViewController.m
//  EMS
//
//  Created by 柏霖尹 on 2019/6/22.
//  Copyright © 2019 work. All rights reserved.
//

#import "EMSNavigationViewController.h"
#import "UIView+Extension.h"
@interface EMSNavigationViewController ()

@end

@implementation EMSNavigationViewController

/**
 *  当第一次使用这个类的时候调用1次
 */
+ (void)initialize
{
    // 通过appearance对象能修改整个项目中所有UIBarButtonItem的样式
    UINavigationBar *appearance = [UINavigationBar appearance];
    // 设置普通状态的文字属性
    appearance.translucent = YES;
    NSMutableDictionary *textAttrs = [NSMutableDictionary dictionary];
    textAttrs[UITextAttributeTextColor] = [UIColor whiteColor];
    textAttrs[UITextAttributeFont] = [UIFont systemFontOfSize:15];
    [appearance setTitleTextAttributes:textAttrs];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.navigationBar setBackgroundImage:[UIImage imageNamed:@"navigationbar_button_background"] forBarMetrics:UIBarMetricsDefault];
    
    //导航栏的背景图和下划线都置空，就会回到默认的设置了
    UIImage *bgImage = [UIImage imageNamed:@"ems_navigation_bar"];
    UIImage *clearImage = [UIImage imageNamed:@"navigationbar_button_background"];
    [self.navigationBar setBackgroundImage:clearImage forBarMetrics:UIBarMetricsDefault];
    [self.navigationBar setShadowImage:[UIImage new]];
    
}


/**
 *  能拦截所有push进来的子控制器
 */
- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    if (self.viewControllers.count > 0) { // 如果现在push的不是栈底控制器(最先push进来的那个控制器)
        // 设置导航栏按钮
        viewController.navigationItem.leftBarButtonItem = [self itemWithImageName:@"ems_btn_back_n" highImageName:@"ems_btn_back_p" target:self action:@selector(back)];
    }
    [super pushViewController:viewController animated:animated];
}

- (void)back
{
#warning 这里用的是self
    [self popViewControllerAnimated:YES];
}

- (UIBarButtonItem *)itemWithImageName:(NSString *)imageName highImageName:(NSString *)highImageName target:(id)target action:(SEL)action
{
    UIButton *button = [[UIButton alloc] init];
    [button setBackgroundImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
    [button setBackgroundImage:[UIImage imageNamed:highImageName] forState:UIControlStateHighlighted];
    [button setImageEdgeInsets:UIEdgeInsetsMake(5, 0, 0, 0)];
    
    
    // 设置按钮的尺寸为背景图片的尺寸
    button.size = button.currentBackgroundImage.size;
    
    // 监听按钮点击
    [button addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    return [[UIBarButtonItem alloc] initWithCustomView:button];
}



@end
