//
//  UIImage+Extension.m
//  EMS
//
//  Created by 柏霖尹 on 2019/6/25.
//  Copyright © 2019 work. All rights reserved.
//

#import "UIImage+Extension.h"

@implementation UIImage (Extension)
+ (UIImage *)imageWithEmsName:(NSString *)name
{
    NSString *str = [NSString stringWithFormat:@"%@2", name];
    return [self imageNamed:str];
}
+ (UIImage *)selectImageWithEmsName:(NSString *)name
{
    NSString *str = [NSString stringWithFormat:@"%@1", name];
    return [self imageNamed:str];
}

+ (UIImage *)resizedImageWithName:(NSString *)name
{

    return [self resizedImageWithName:name left:0.5 top:0.5];
}

+ (UIImage *)resizedImageWithName:(NSString *)name left:(CGFloat)left top:(CGFloat)top
{
    UIImage *image = [self imageNamed:name];
    return [image stretchableImageWithLeftCapWidth:image.size.width * left topCapHeight:image.size.height * top];
}
@end
