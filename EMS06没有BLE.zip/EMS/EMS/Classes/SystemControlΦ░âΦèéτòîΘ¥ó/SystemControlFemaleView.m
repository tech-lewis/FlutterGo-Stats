//
//  SystemControlFemaleView.m
//  EMS
//
//  Created by 柏霖尹 on 2019/6/27.
//  Copyright © 2019 work. All rights reserved.
//

#import "SystemControlFemaleView.h"
@interface SystemControlFemaleView()

@end

@implementation SystemControlFemaleView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
