//
//  EMSPopupView.h
//  EMS
//
//  Created by 柏霖尹 on 2019/7/1.
//  Copyright © 2019 work. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@class EMSPopupView;

@protocol EMSPopupViewDelegate <NSObject>
- (void)popViewConfirmButtonClicked:(EMSPopupView *)view;
@end


@interface EMSPopupView : UIView
@property (nonatomic, weak) id<EMSPopupViewDelegate> delegate;
+ (instancetype)popupViewWithDeviceName:(NSString *)name;

+ (instancetype)popupViewWithConnectedDeviceName:(NSString *)name;
@end

NS_ASSUME_NONNULL_END
