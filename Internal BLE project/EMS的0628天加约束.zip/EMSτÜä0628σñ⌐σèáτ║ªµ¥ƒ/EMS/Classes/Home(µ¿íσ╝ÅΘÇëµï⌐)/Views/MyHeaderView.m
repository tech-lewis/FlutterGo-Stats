//
//  MyHeaderView.m
//  EMS
//
//  Created by 柏霖尹 on 2019/6/24.
//  Copyright © 2019 work. All rights reserved.
//

#import "MyHeaderView.h"
#import "EMSGroup.h"
#import "EMSMenuModel.h"
@interface MyHeaderView()
@property (nonatomic, weak) UIButton *nameView;

@end


@implementation MyHeaderView

+ (instancetype)headerViewWithTableView:(UITableView *)tableView
{
    static NSString *ID = @"header";
    MyHeaderView *header = [tableView dequeueReusableHeaderFooterViewWithIdentifier:ID];
    if (header == nil)
    {
        header = [[MyHeaderView alloc] initWithReuseIdentifier:ID];
    }
    return header;
}

/**
 *  在这个初始化方法中HeaderView的frame\bounds没有值
 */
- (id)initWithReuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithReuseIdentifier:reuseIdentifier]) {
        // 添加子控件
        // 1.背景图片
        UIImageView *imageView = [[UIImageView alloc] init];
        [self.contentView addSubview:imageView];
        self.bgImageView = imageView;

        // 2.添加按钮
        UIButton *nameView = [UIButton buttonWithType:UIButtonTypeCustom];

        UIImage *clearImage = [UIImage imageNamed:@"navigationbar_button_background"];
        [nameView setBackgroundImage:clearImage forState:UIControlStateNormal];
//        [nameView setBackgroundImage:[UIImage imageNamed:@"ems_main_list01_sel"] forState:UIControlStateSelected];
        // 设置按钮内部的左边箭头图片
        // [nameView setImage:[UIImage imageNamed:@"buddy_header_arrow"] forState:UIControlStateNormal];
        [nameView setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        // 设置按钮的内容左对齐
        nameView.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        // 设置按钮的内边距
        nameView.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
        nameView.contentEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
        [nameView addTarget:self action:@selector(nameViewClick) forControlEvents:UIControlEventTouchUpInside];

        [self.contentView addSubview:nameView];
        self.nameView = nameView;
        
        
    }
    return self;
}




/**
 *  当一个控件的frame发生改变的时候就会调用
 *
 *  一般在这里布局内部的子控件(设置子控件的frame)
 */
- (void)layoutSubviews
{
#warning 一定要调用super的方法
    [super layoutSubviews];
    
    // 1.设置按钮的frame
    self.nameView.frame = self.bounds;
    
    // 2.背景图片的frame
    self.bgImageView.frame = self.bounds;
}

- (void)setGroup:(EMSGroup *)group
{
    _group = group;
    
    // 1.设置按钮文字(组名)
    [self.nameView setTitle:group.name forState:UIControlStateNormal];
    [self.nameView setTitle:group.nameSelected forState:UIControlStateSelected];
    
    // 3.重新设置左边箭头的状态
    [self didMoveToSuperview];
    //    if (self.group.isOpened) {
    //        self.nameView.imageView.transform = CGAffineTransformMakeRotation(M_PI_2);
    //    } else {
    //        self.nameView.imageView.transform = CGAffineTransformMakeRotation(0);
    //    }
}

/**
 *  监听组名按钮的点击
 */
- (void)nameViewClick
{
    // 1.修改组模型的标记(状态取反)
    self.group.opened = !self.group.isOpened;
    
    // 2.刷新表格
    if ([self.delegate respondsToSelector:@selector(headerViewDidClickedNameView:)])
    {
        [self.delegate headerViewDidClickedNameView:self];
        
    }
}

/**
 *  当一个控件被添加到父控件中就会调用
 */
- (void)didMoveToSuperview
{
    if (self.group.isOpened)
    {
        self.nameView.imageView.transform = CGAffineTransformMakeRotation(M_PI);
    }
    else
    {
        self.nameView.imageView.transform = CGAffineTransformMakeRotation(0);
    }
}
@end
