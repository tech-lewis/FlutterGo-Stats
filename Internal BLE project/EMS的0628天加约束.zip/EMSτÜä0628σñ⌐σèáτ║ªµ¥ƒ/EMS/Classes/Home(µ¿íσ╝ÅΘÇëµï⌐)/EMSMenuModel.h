//
//  EMSMenuModel.h
//  EMS
//
//  Created by 柏霖尹 on 2019/6/24.
//  Copyright © 2019 work. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface EMSMenuModel : NSObject
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *selectName; // 韩文字

+ (instancetype)menuWithDict:(NSDictionary *)dict;
- (instancetype)initWithDict:(NSDictionary *)dict;
@end

NS_ASSUME_NONNULL_END
